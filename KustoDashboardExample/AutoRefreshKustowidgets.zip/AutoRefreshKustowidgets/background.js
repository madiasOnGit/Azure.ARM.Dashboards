chrome.browserAction.onClicked.addListener(function(tab) {
    chrome.browserAction.getTitle({tabId: tab.id}, function(title) {
        var newTitle, newIcon;
        if (title.indexOf("Start") == 0) 
		{
            newTitle = "Stop me";  
			newIcon = "stop";
		}
        else {
            newTitle = "Start me"; newIcon = "start";
        }
        chrome.browserAction.setTitle({tabId: tab.id, title: newTitle});
        chrome.browserAction.setIcon({
            tabId: tab.id,
            path: {
                19: "icon-"+newIcon+"-19x19.png",
                38: "icon-"+newIcon+"-38x38.png"
            }
        });
        chrome.tabs.executeScript({file: "content.js"});
    });
});