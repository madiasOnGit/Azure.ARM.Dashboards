if (interval) {
    clearInterval(interval);
    interval = 0;
} else {
    var btn = document.querySelector("button.something");
    if (btn) {
        var interval = setInterval(function() {
            btn.click();
        }, 60 * 1000);
    }
}