browser.browserAction.onClicked.addListener(function(tab) {
	
	 browser.browserAction.getTitle({tabId: tab.id}, function(title) {
        var newTitle, newIcon;
        if (title.indexOf("Start") == 0) 
		{
            newTitle = "Stop me";  
			newIcon = "stop";
		}
        else {
            newTitle = "Start me"; newIcon = "start";
        }
        browser.browserAction.setTitle({tabId: tab.id, title: newTitle});
        browser.browserAction.setIcon({
            tabId: tab.id,
            path: {
                19: "icon-"+newIcon+"-19x19.png",
                38: "icon-"+newIcon+"-38x38.png"
            }
        });
        browser.tabs.executeScript(tab.id,{file: "/content.js"});
    });


});
