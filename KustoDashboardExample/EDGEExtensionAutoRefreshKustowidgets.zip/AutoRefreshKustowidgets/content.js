
if (interval) {
    clearInterval(interval);
    interval = 0;
} else {
	var btns = document.querySelectorAll(".azc-toolbarButton-command");
	if(btns){
		 var interval = setInterval(function() {
			var i;
			for (i = 0; i < btns.length; i++) {
				if(btns[i].title.includes("Refresh"))
				{
					btns[i].click();
				}
    			
			} 
        }, 60 *  1000);
		
	}
	
}
